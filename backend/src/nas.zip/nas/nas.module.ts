import { Module } from '@nestjs/common';
import { NasController } from './nas.controller';
import { NasService } from './nas.service';
import { MikrotikSyncService } from './mikrotik-sync.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [NasController],
  providers: [NasService, MikrotikSyncService],
  exports: [NasService],
})
export class NasModule {}