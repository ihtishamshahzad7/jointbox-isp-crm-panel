import { Injectable, Logger } from '@nestjs/common';
import * as net from 'net';
import { withMikrotik } from './mikrotik.client';

export interface NasReachability {
  pingReachable: boolean;
  apiPortOpen: boolean;
  radiusPortOpen: boolean;
  incomingPortOpen: boolean;
  responseTimeMs: number | null;
  lastChecked: Date;
}

export interface MikrotikDetails {
  identity: string;
  version: string;
  board: string;
  uptime: string;
  cpuLoad: string;
  totalMemory: string;
  freeMemory: string;
  totalHdd: string;
  freeHdd: string;
  interfaces: MikrotikInterface[];
  pppoeServer: PppoeServerInfo | null;
  radiusClients: RadiusClient[];
  apiService: ApiServiceInfo | null;
  ipAddresses: IpAddress[];
  pppoeProfiles: PppoeProfile[];
  activeConnections: number;
}

export interface MikrotikInterface {
  name: string;
  type: string;
  mtu: string;
  macAddress: string;
  running: string;
  disabled: string;
  comment: string;
}

export interface PppoeServerInfo {
  enabled: boolean;
  interface: string;
  serviceName: string;
  maxMtu: string;
  maxMru: string;
  authentication: string;
  keepaliveTimeout: string;
  defaultProfile: string;
}

export interface PppoeProfile {
  name: string;
  localAddress: string;
  remoteAddress: string;
  rateLimit: string;
  sessionTimeout: string;
  comment: string;
}

export interface RadiusClient {
  service: string;
  address: string;
  secret: string;
  authPort: string;
  acctPort: string;
  timeout: string;
  disabled: string;
}

export interface ApiServiceInfo {
  enabled: boolean;
  port: string;
  tlsPort: string;
  disabled: string;
}

export interface IpAddress {
  address: string;
  network: string;
  interface: string;
  disabled: string;
}

@Injectable()
export class MikrotikSyncService {
  private readonly logger = new Logger(MikrotikSyncService.name);
  private readonly LOCALHOST = '127.0.0.1';
  private readonly RADIUS_AUTH_PORT = 1812;
  private readonly RADIUS_ACCT_PORT = 1813;

  private checkPort(host: string, port: number, timeoutMs = 5000): Promise<boolean> {
    return new Promise((resolve) => {
      const socket = new net.Socket();
      socket.setTimeout(timeoutMs);
      socket
        .on('connect', () => { socket.destroy(); resolve(true); })
        .on('timeout', () => { socket.destroy(); resolve(false); })
        .on('error', () => { socket.destroy(); resolve(false); });
      socket.connect(port, host);
    });
  }

  private async tcpPing(host: string, port: number): Promise<number | null> {
    const start = Date.now();
    const reachable = await this.checkPort(host, port, 5000);
    return reachable ? Date.now() - start : null;
  }

  /**
   * Check reachability of NAS (Mikrotik) and local services
   * - API port: checked on the Mikrotik device
   * - RADIUS port: checked locally (runs on this server)
   * - CoA port: checked locally (runs on this server)
   */
  async checkReachability(
    nasIp: string,
    apiPort: number,
    incomingPort: number,
  ): Promise<NasReachability> {
    const [apiOpen, radiusAuthOpen, coaOpen, responseTimeMs] = await Promise.all([
      this.checkPort(nasIp, apiPort),                    // API on Mikrotik ✅
      this.checkPort(this.LOCALHOST, this.RADIUS_AUTH_PORT), // RADIUS on local server ✅
      this.checkPort(this.LOCALHOST, incomingPort),      // CoA on local server ✅
      this.tcpPing(nasIp, apiPort),                      // Response time from Mikrotik
    ]);

    return {
      pingReachable: apiOpen || radiusAuthOpen || coaOpen,
      apiPortOpen: apiOpen,
      radiusPortOpen: radiusAuthOpen,
      incomingPortOpen: coaOpen,
      responseTimeMs,
      lastChecked: new Date(),
    };
  }

  /**
   * Check if local RADIUS server is properly configured and listening
   */
  async checkLocalRadiusServer(): Promise<{
    radiusListening: boolean;
    coaListening: boolean;
    radiusPort: number;
    coaPort: number;
  }> {
    const [radiusListening, coaListening] = await Promise.all([
      this.checkPort(this.LOCALHOST, this.RADIUS_AUTH_PORT),
      this.checkPort(this.LOCALHOST, this.RADIUS_ACCT_PORT),
    ]);

    return {
      radiusListening,
      coaListening,
      radiusPort: this.RADIUS_AUTH_PORT,
      coaPort: this.RADIUS_ACCT_PORT,
    };
  }

  async syncDetails(
    nasIp: string,
    apiPort: number,
    apiUsername: string,
    apiPassword: string,
  ): Promise<MikrotikDetails> {
    return withMikrotik(
      { host: nasIp, port: apiPort, username: apiUsername, password: apiPassword, timeout: 12000 },
      async (client) => {
        const [
          identity,
          resource,
          interfaces,
          pppoeServers,
          pppoeProfiles,
          radiusClients,
          apiServices,
          ipAddresses,
          activeSecrets,
        ] = await Promise.all([
          client.send(['/system/identity/print']).catch(() => []),
          client.send(['/system/resource/print']).catch(() => []),
          client.send(['/interface/print']).catch(() => []),
          client.send(['/interface/pppoe-server/server/print']).catch(() => []),
          client.send(['/ppp/profile/print']).catch(() => []),
          client.send(['/radius/print']).catch(() => []),
          client.send(['/ip/service/print', '?name=api']).catch(() => []),
          client.send(['/ip/address/print']).catch(() => []),
          client.send(['/ppp/active/print', 'count-only']).catch(() => []),
        ]);

        const res = resource[0] || {};
        const id = identity[0] || {};
        const api = apiServices.find((s) => s.name === 'api') || apiServices[0];
        const apiTls = apiServices.find((s) => s.name === 'api-ssl');

        return {
          identity: id.name || nasIp,
          version: res.version || 'Unknown',
          board: res['board-name'] || 'Unknown',
          uptime: res.uptime || 'Unknown',
          cpuLoad: res['cpu-load'] ? `${res['cpu-load']}%` : 'Unknown',
          totalMemory: res['total-memory'] || 'Unknown',
          freeMemory: res['free-memory'] || 'Unknown',
          totalHdd: res['total-hdd-space'] || 'Unknown',
          freeHdd: res['free-hdd-space'] || 'Unknown',
          interfaces: interfaces.map((i) => ({
            name: i.name || '',
            type: i.type || '',
            mtu: i.mtu || '',
            macAddress: i['mac-address'] || '',
            running: i.running || 'false',
            disabled: i.disabled || 'false',
            comment: i.comment || '',
          })),
          pppoeServer: pppoeServers[0] ? {
            enabled: pppoeServers[0].disabled !== 'true',
            interface: pppoeServers[0].interface || '',
            serviceName: pppoeServers[0]['service-name'] || '',
            maxMtu: pppoeServers[0]['max-mtu'] || '',
            maxMru: pppoeServers[0]['max-mru'] || '',
            authentication: pppoeServers[0].authentication || '',
            keepaliveTimeout: pppoeServers[0]['keepalive-timeout'] || '',
            defaultProfile: pppoeServers[0]['default-profile'] || '',
          } : null,
          pppoeProfiles: pppoeProfiles.map((p) => ({
            name: p.name || '',
            localAddress: p['local-address'] || '',
            remoteAddress: p['remote-address'] || '',
            rateLimit: p['rate-limit'] || '',
            sessionTimeout: p['session-timeout'] || '',
            comment: p.comment || '',
          })),
          radiusClients: radiusClients.map((r) => ({
            service: r.service || '',
            address: r.address || '',
            secret: r.secret || '',
            authPort: r['auth-port'] || '1812',
            acctPort: r['acct-port'] || '1813',
            timeout: r.timeout || '',
            disabled: r.disabled || 'false',
          })),
          apiService: api ? {
            enabled: api.disabled !== 'true',
            port: api.port || '8728',
            tlsPort: apiTls?.port || '8729',
            disabled: api.disabled || 'false',
          } : null,
          ipAddresses: ipAddresses.map((ip) => ({
            address: ip.address || '',
            network: ip.network || '',
            interface: ip.interface || '',
            disabled: ip.disabled || 'false',
          })),
          activeConnections: parseInt(activeSecrets[0]?.ret || '0', 10),
        };
      },
    );
  }

  async quickCheck(
    nasIp: string,
    apiPort: number,
    apiUsername: string,
    apiPassword: string,
  ): Promise<{ online: boolean; identity: string; version: string; cpuLoad: string; uptime: string; activeConnections: number }> {
    try {
      return await withMikrotik(
        { host: nasIp, port: apiPort, username: apiUsername, password: apiPassword, timeout: 8000 },
        async (client) => {
          const [identity, resource, active] = await Promise.all([
            client.send(['/system/identity/print']).catch(() => []),
            client.send(['/system/resource/print']).catch(() => []),
            client.send(['/ppp/active/print', 'count-only']).catch(() => []),
          ]);
          const res = resource[0] || {};
          return {
            online: true,
            identity: identity[0]?.name || nasIp,
            version: res.version || '',
            cpuLoad: res['cpu-load'] ? `${res['cpu-load']}%` : '',
            uptime: res.uptime || '',
            activeConnections: parseInt(active[0]?.ret || '0', 10),
          };
        },
      );
    } catch {
      return { online: false, identity: '', version: '', cpuLoad: '', uptime: '', activeConnections: 0 };
    }
  }
}