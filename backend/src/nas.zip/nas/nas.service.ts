import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NasType } from '@prisma/client';
import { MikrotikSyncService } from './mikrotik-sync.service';

@Injectable()
export class NasService {
  constructor(
    private prisma: PrismaService,
    private mikrotikSync: MikrotikSyncService,
  ) {}

  async findAll() {
    return this.prisma.nas.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { subscribers: true } },
      },
    });
  }

  async findOne(id: number) {
    return this.prisma.nas.findUnique({
      where: { id },
      include: {
        subscribers: true,
        _count: { select: { subscribers: true } },
      },
    });
  }

  private resolveNasType(raw?: string): NasType {
    const map: Record<string, NasType> = {
      CISCO:    NasType.CISCO,
      HUAWEI:   NasType.HUAWEI,
      OTHER:    NasType.OTHER,
      MIKROTIK: NasType.MIKROTIK,
    };
    return map[raw?.toUpperCase() ?? ''] ?? NasType.MIKROTIK;
  }

  async create(data: {
    nasIp:        string;
    nasName:      string;
    radiusSecret: string;
    incomingPort?: number;
    apiPort?:      number;
    apiUsername?:  string;
    apiPassword?:  string;
    nasType?:      string;
    isActive?:     boolean;
    description?:  string;
  }) {
    return this.prisma.nas.create({
      data: {
        nasIp:        data.nasIp,
        nasName:      data.nasName,
        radiusSecret: data.radiusSecret,
        incomingPort: data.incomingPort ?? 3799,
        apiPort:      data.apiPort      ?? 8728,
        apiUsername:  data.apiUsername,
        apiPassword:  data.apiPassword,
        nasType:      this.resolveNasType(data.nasType),
        isActive:     data.isActive     ?? true,
        description:  data.description,
      },
    });
  }

  async update(id: number, data: any) {
    if (data.nasType) data.nasType = this.resolveNasType(data.nasType);
    return this.prisma.nas.update({ where: { id }, data });
  }

  async remove(id: number) {
    return this.prisma.nas.delete({ where: { id } });
  }

  async toggleStatus(id: number) {
    const nas = await this.prisma.nas.findUnique({ where: { id } });
    if (!nas) throw new Error('NAS not found');
    return this.prisma.nas.update({ where: { id }, data: { isActive: !nas.isActive } });
  }

  async getStats() {
    const total    = await this.prisma.nas.count();
    const active   = await this.prisma.nas.count({ where: { isActive: true } });
    const inactive = await this.prisma.nas.count({ where: { isActive: false } });
    const mikrotik = await this.prisma.nas.count({ where: { nasType: 'MIKROTIK' } });
    const cisco    = await this.prisma.nas.count({ where: { nasType: 'CISCO' } });
    const other    = await this.prisma.nas.count({ where: { nasType: { notIn: ['MIKROTIK', 'CISCO'] } } });
    return { total, active, inactive, mikrotik, cisco, other };
  }

  // ========== MIKROTIK SYNC METHODS ==========
  async checkReachability(id: number) {
    const nas = await this.prisma.nas.findUnique({ where: { id } });
    if (!nas) throw new Error('NAS not found');
    return this.mikrotikSync.checkReachability(nas.nasIp, nas.apiPort, nas.incomingPort);
  }

  async syncDetails(id: number) {
    const nas = await this.prisma.nas.findUnique({ where: { id } });
    if (!nas) throw new Error('NAS not found');
    if (!nas.apiUsername || !nas.apiPassword) {
      throw new Error('API credentials not configured for this NAS');
    }
    return this.mikrotikSync.syncDetails(nas.nasIp, nas.apiPort, nas.apiUsername, nas.apiPassword);
  }

  async quickCheck(id: number) {
    const nas = await this.prisma.nas.findUnique({ where: { id } });
    if (!nas) throw new Error('NAS not found');
    if (!nas.apiUsername || !nas.apiPassword) {
      return { online: false, identity: '', version: '', cpuLoad: '', uptime: '', activeConnections: 0 };
    }
    return this.mikrotikSync.quickCheck(nas.nasIp, nas.apiPort, nas.apiUsername, nas.apiPassword);
  }
}