import {
  Controller, Get, Post, Put, Delete,
  Body, Param, UseGuards, Patch,
} from '@nestjs/common';
import { NasService } from './nas.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('nas')
export class NasController {
  constructor(private readonly nasService: NasService) {}

  @Get()
  findAll() { 
    return this.nasService.findAll(); 
  }

  @Get('stats')
  getStats() { 
    return this.nasService.getStats(); 
  }

  @Get(':id')
  findOne(@Param('id') id: string) { 
    return this.nasService.findOne(+id); 
  }

  @Post()
  create(@Body() body: any) { 
    return this.nasService.create(body); 
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() body: any) {
    return this.nasService.update(+id, body);
  }

  @Patch(':id/toggle')
  toggleStatus(@Param('id') id: string) {
    return this.nasService.toggleStatus(+id);
  }

  @Delete(':id')
  remove(@Param('id') id: string) { 
    return this.nasService.remove(+id); 
  }

  // ========== MIKROTIK SYNC ENDPOINTS ==========
  @Get(':id/reachability')
  checkReachability(@Param('id') id: string) {
    return this.nasService.checkReachability(+id);
  }

  @Get(':id/sync')
  syncDetails(@Param('id') id: string) {
    return this.nasService.syncDetails(+id);
  }

  @Get(':id/quick-check')
  quickCheck(@Param('id') id: string) {
    return this.nasService.quickCheck(+id);
  }
}