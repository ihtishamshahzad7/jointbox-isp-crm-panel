import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
  ) {}

  async register(name: string, email: string, password: string) {
    const hashed = await bcrypt.hash(password, 10);

    const user = await this.prisma.user.create({
      data: {
        name,
        email,
        password: hashed,
      },
    });

    return {
      message: 'User registered successfully 🚀',
      user,
    };
  }

  async login(email: string, password: string) {
    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      return { message: 'User not found ❌' };
    }

    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return { message: 'Wrong password ❌' };
    }

    const token = this.jwt.sign({
      sub: user.id,
      email: user.email,
    });

    return {
      message: 'Login successful 🚀',
      token,
      user,
    };
  }
}