import {
  Controller, Get, Post, Put, Delete,
  Body, Param, UseGuards, Patch
} from '@nestjs/common';
import { AreasService } from './areas.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('areas')
export class AreasController {
  constructor(private readonly areasService: AreasService) {}

  @Get()
  findAll() { return this.areasService.findAll(); }

  @Get('stats')
  getStats() { return this.areasService.getStats(); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.areasService.findOne(+id); }

  @Post()
  create(@Body() body: any) { return this.areasService.create(body); }

  @Put(':id')
  update(@Param('id') id: string, @Body() body: any) {
    return this.areasService.update(+id, body);
  }

  @Patch(':id/toggle')
  toggleStatus(@Param('id') id: string) {
return this.areasService.toggleArea(+id);  }

  @Delete(':id')
  remove(@Param('id') id: string) { return this.areasService.remove(+id); }
}