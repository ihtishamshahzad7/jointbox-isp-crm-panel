import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  async getDashboardStats() {
    const [
      subscribers,
      packages,
      areas,
      nas,
      invoices,
      vouchers,
      users,
      tickets,
      payments,
    ] = await Promise.all([
      this.prisma.subscriber.count(),
      this.prisma.package.count(),
      this.prisma.area.count(),
      this.prisma.nas.count(),
      this.prisma.invoice.count(),
      this.prisma.voucher.count(),
      this.prisma.user.count(),
      this.prisma.ticket.count(),
      this.prisma.payment.aggregate({ _sum: { amount: true } }),
    ]);

    return {
      subscribers,
      packages,
      areas,
      nas,
      invoices,
      vouchers,
      users,
      tickets,
      totalRevenue: payments._sum.amount ?? 0,
    };
  }

  async getRevenueReport(startDate?: string, endDate?: string) {
    const where: any = {};
    if (startDate && endDate) {
      where.paymentDate = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const payments = await this.prisma.payment.findMany({
      where,
      include: {
        subscriber: true,
        invoice:    true,
      },
      orderBy: { paymentDate: 'desc' },
    });

    const total    = payments.reduce((sum, p) => sum + p.amount, 0);
    const byMethod = payments.reduce((acc: any, p) => {
      acc[p.method] = (acc[p.method] || 0) + p.amount;
      return acc;
    }, {});

    return { payments, total, byMethod, count: payments.length };
  }

  async getSubscriberReport() {
    const active    = await this.prisma.subscriber.count({ where: { status: 'ACTIVE' } });
    const inactive  = await this.prisma.subscriber.count({ where: { status: 'INACTIVE' } });
    const expired   = await this.prisma.subscriber.count({ where: { status: 'EXPIRED' } });
    const suspended = await this.prisma.subscriber.count({ where: { status: 'SUSPENDED' } });

    const byPackage = await this.prisma.subscriber.groupBy({
      by:    ['packageId'],
      _count: true,
      where: { packageId: { not: null } },
    });

    return {
      active,
      inactive,
      expired,
      suspended,
      total: active + inactive + expired + suspended,
      byPackage,
    };
  }

  async getTicketReport() {
    const open       = await this.prisma.ticket.count({ where: { status: 'OPEN' } });
    const inProgress = await this.prisma.ticket.count({ where: { status: 'IN_PROGRESS' } });
    const resolved   = await this.prisma.ticket.count({ where: { status: 'RESOLVED' } });
    const closed     = await this.prisma.ticket.count({ where: { status: 'CLOSED' } });

    const byCategory = await this.prisma.ticket.groupBy({
      by:    ['category'],
      _count: true,
    });

    return {
      open,
      inProgress,
      resolved,
      closed,
      total: open + inProgress + resolved + closed,
      byCategory,
    };
  }
}
