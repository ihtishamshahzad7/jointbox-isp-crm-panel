import {
  Controller, Get, Query, UseGuards,
} from '@nestjs/common';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('dashboard')
  getDashboardStats() {
    return this.reportsService.getDashboardStats();
  }

  @Get('revenue')
  getRevenueReport(@Query('startDate') startDate?: string, @Query('endDate') endDate?: string) {
    return this.reportsService.getRevenueReport(startDate, endDate);
  }

  @Get('subscribers')
  getSubscriberReport() {
    return this.reportsService.getSubscriberReport();
  }

  @Get('tickets')
  getTicketReport() {
    return this.reportsService.getTicketReport();
  }
}