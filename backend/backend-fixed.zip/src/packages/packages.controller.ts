import {
  Controller, Get, Post, Put, Delete,
  Body, Param, UseGuards, Patch, Query,
} from '@nestjs/common';
import { PackagesService } from './packages.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('packages')
export class PackagesController {
  constructor(private readonly packagesService: PackagesService) {}

  @Get()
  findAll() {
    return this.packagesService.findAll();
  }

  @Get('stats')
  getStats() {
    return this.packagesService.getStats();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.packagesService.findOne(+id);
  }

  @Post()
  create(@Body() body: any) {
    return this.packagesService.create(body);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() body: any) {
    return this.packagesService.update(+id, body);
  }

  @Patch(':id/toggle')
  toggleStatus(@Param('id') id: string) {
    return this.packagesService.toggleStatus(+id);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.packagesService.remove(+id);
  }
}