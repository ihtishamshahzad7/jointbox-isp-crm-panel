import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';

import { AuthModule } from './auth/auth.module';
import { PrismaModule } from './prisma/prisma.module';
import { SubscribersModule } from './subscribers/subscribers.module';
import { PackagesModule } from './packages/packages.module';
import { AreasModule } from './areas/areas.module';
import { NasModule } from './nas/nas.module';
import { ServiceSettingsModule } from './service-settings/service-settings.module';
import { InvoicesModule } from './invoices/invoices.module';
import { VouchersModule } from './vouchers/vouchers.module';
import { UsersModule } from './users/users.module';
import { TicketsModule } from './tickets/tickets.module';
import { PaymentsModule } from './payments/payments.module';
import { ReportsModule } from './reports/reports.module';

@Module({
  imports: [
    AuthModule,
    PrismaModule,
    SubscribersModule,
    PackagesModule,
    AreasModule,
    NasModule,
    ServiceSettingsModule,
    InvoicesModule,
    VouchersModule,
    UsersModule,
    TicketsModule,
    PaymentsModule,
    ReportsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}