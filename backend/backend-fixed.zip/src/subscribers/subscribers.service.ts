import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SubscribersService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.subscriber.findMany({
      include: {
        package:    true,
        area:       true,
        nas:        true,
        salesperson: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    return this.prisma.subscriber.findUnique({
      where: { id },
      include: {
        package:    true,
        area:       true,
        nas:        true,
        salesperson: true,
      },
    });
  }

  async search(q: string) {
    return this.prisma.subscriber.findMany({
      where: {
        OR: [
          { fullName: { contains: q, mode: 'insensitive' } },
          { phone:    { contains: q } },
          { username: { contains: q, mode: 'insensitive' } },
          { email:    { contains: q, mode: 'insensitive' } },
          { identity: { contains: q } },
        ],
      },
      include: {
        package:    true,
        area:       true,
        nas:        true,
        salesperson: true,
      },
    });
  }

  async getStats() {
    const total     = await this.prisma.subscriber.count();
    const active    = await this.prisma.subscriber.count({ where: { status: 'ACTIVE' } });
    const expired   = await this.prisma.subscriber.count({ where: { status: 'EXPIRED' } });
    const suspended = await this.prisma.subscriber.count({ where: { status: 'SUSPENDED' } });
    return { total, active, expired, suspended };
  }

  async create(data: any) {
    return this.prisma.subscriber.create({
      data: {
        fullName:         data.fullName,
        phone:            data.phone,
        email:            data.email,
        address:          data.address,
        username:         data.username,
        password:         data.password,
        identity:         data.identity,
        connectionType:   data.connectionType   || 'FTTH',
        packageId:        data.packageId        ? parseInt(data.packageId)     : null,
        areaId:           data.areaId           ? parseInt(data.areaId)        : null,
        nasId:            data.nasId            ? parseInt(data.nasId)         : null,
        salespersonId:    data.salespersonId    ? parseInt(data.salespersonId) : null,
        documentUrl:      data.documentUrl,
        installationDate: data.installationDate ? new Date(data.installationDate) : null,
        latitude:         data.latitude         ? parseFloat(data.latitude)    : null,
        longitude:        data.longitude        ? parseFloat(data.longitude)   : null,
      },
    });
  }

  async update(id: number, data: any) {
    return this.prisma.subscriber.update({
      where: { id },
      data: {
        fullName:         data.fullName,
        phone:            data.phone,
        email:            data.email,
        address:          data.address,
        username:         data.username,
        password:         data.password,
        identity:         data.identity,
        connectionType:   data.connectionType,
        packageId:        data.packageId        ? parseInt(data.packageId)     : null,
        areaId:           data.areaId           ? parseInt(data.areaId)        : null,
        nasId:            data.nasId            ? parseInt(data.nasId)         : null,
        salespersonId:    data.salespersonId    ? parseInt(data.salespersonId) : null,
        documentUrl:      data.documentUrl,
        installationDate: data.installationDate ? new Date(data.installationDate) : null,
        latitude:         data.latitude         ? parseFloat(data.latitude)    : null,
        longitude:        data.longitude        ? parseFloat(data.longitude)   : null,
      },
    });
  }

  async remove(id: number) {
    return this.prisma.subscriber.delete({ where: { id } });
  }
}
