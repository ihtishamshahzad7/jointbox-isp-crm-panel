import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class InvoicesService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.invoice.findMany({
      include: {
        subscriber: true,
        items: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    return this.prisma.invoice.findUnique({
      where: { id },
      include: {
        subscriber: true,
        items: true,
        payments: true,
      },
    });
  }

  async findBySubscriber(subscriberId: number) {
    return this.prisma.invoice.findMany({
      where: { subscriberId },
      include: {
        items: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getStats() {
    const total   = await this.prisma.invoice.count();
    const unpaid  = await this.prisma.invoice.count({ where: { status: 'UNPAID' } });
    const partial = await this.prisma.invoice.count({ where: { status: 'PARTIAL' } });
    const paid    = await this.prisma.invoice.count({ where: { status: 'PAID' } });
    const overdue = await this.prisma.invoice.count({ where: { status: 'OVERDUE' } });

    const totalAmount = await this.prisma.invoice.aggregate({ _sum: { total: true } });
    const totalPaid   = await this.prisma.invoice.aggregate({ _sum: { paidAmount: true } });
    const totalDue    = await this.prisma.invoice.aggregate({ _sum: { dueAmount: true } });

    return {
      total,
      unpaid,
      partial,
      paid,
      overdue,
      totalAmount:  totalAmount._sum.total      ?? 0,
      totalPaid:    totalPaid._sum.paidAmount    ?? 0,
      totalDue:     totalDue._sum.dueAmount      ?? 0,
    };
  }

  async generateInvoiceNo() {
    const year  = new Date().getFullYear();
    const count = await this.prisma.invoice.count();
    return `INV-${year}-${String(count + 1).padStart(5, '0')}`;
  }

  async create(data: any) {
    const invoiceNo = await this.generateInvoiceNo();
    const total     = data.amount + (data.tax || 0) - (data.discount || 0);

    return this.prisma.invoice.create({
      data: {
        invoiceNo,
        subscriberId: data.subscriberId,
        amount:       data.amount,
        tax:          data.tax      || 0,
        discount:     data.discount || 0,
        total,
        paidAmount:   0,
        dueAmount:    total,
        dueDate:      new Date(data.dueDate),
        notes:        data.notes,
        status:       'UNPAID',
        items: {
          create: data.items || [],
        },
      },
      include: { items: true },
    });
  }

  async recordPayment(invoiceId: number, data: any) {
    const invoice = await this.prisma.invoice.findUnique({ where: { id: invoiceId } });
    if (!invoice) throw new Error('Invoice not found');

    const newPaidAmount = invoice.paidAmount + data.amount;
    const newDueAmount  = invoice.total - newPaidAmount;

    let status: 'UNPAID' | 'PARTIAL' | 'PAID' | 'OVERDUE' = 'PARTIAL';
    if (newPaidAmount >= invoice.total) status = 'PAID';

    const paymentNo = `PAY-${Date.now()}`;

    await this.prisma.payment.create({
      data: {
        paymentNo,
        invoiceId,
        subscriberId: invoice.subscriberId,
        amount:       data.amount,
        method:       data.method,
        referenceNo:  data.referenceNo,
        notes:        data.notes,
        receivedBy:   data.receivedBy,
      },
    });

    return this.prisma.invoice.update({
      where: { id: invoiceId },
      data: {
        paidAmount: newPaidAmount,
        dueAmount:  newDueAmount,
        status,
        paidDate: status === 'PAID' ? new Date() : null,
      },
    });
  }
}
