import {
  Controller, Get, Post, Put, Delete,
  Body, Param, UseGuards,
} from '@nestjs/common';
import { TicketsService } from './tickets.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('tickets')
export class TicketsController {
  constructor(private readonly ticketsService: TicketsService) {}

  @Get()
  findAll() {
    return this.ticketsService.findAll();
  }

  @Get('stats')
  getStats() {
    return this.ticketsService.getStats();
  }

  @Get('subscriber/:subscriberId')
  findBySubscriber(@Param('subscriberId') subscriberId: string) {
    return this.ticketsService.findBySubscriber(+subscriberId);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.ticketsService.findOne(+id);
  }

  @Post()
  create(@Body() body: any) {
    return this.ticketsService.create(body);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() body: any) {
    return this.ticketsService.update(+id, body);
  }

  @Post(':id/message')
  addMessage(@Param('id') id: string, @Body() body: any) {
    return this.ticketsService.addMessage(+id, body);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.ticketsService.delete(+id);
  }
}