import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    const users = await this.prisma.user.findMany({
      select: {
        id:        true,
        name:      true,
        email:     true,
        role:      true,
        phone:     true,
        address:   true,
        isActive:  true,
        balance:   true,
        createdAt: true,
        updatedAt: true,
        parentId:  true,
        parent: {
          select: { id: true, name: true, email: true, role: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return Promise.all(
      users.map(async (user) => {
        const [ownedSubscribersCount, childrenCount, paymentsCount, ticketsCount] =
          await Promise.all([
            this.prisma.subscriber.count({ where: { userId: user.id } }),
            this.prisma.user.count({ where: { parentId: user.id } }),
            this.prisma.payment.count({ where: { receivedBy: user.id } }),
            this.prisma.ticket.count({ where: { assignedTo: user.id } }),
          ]);
        return {
          ...user,
          _count: {
            ownedSubscribers: ownedSubscribersCount,
            children:         childrenCount,
            payments:         paymentsCount,
            assignedTickets:  ticketsCount,
          },
        };
      }),
    );
  }

  async findAllPaginated(
    page:    number = 1,
    limit:   number = 10,
    filters?: { role?: string; isActive?: boolean; search?: string },
  ) {
    const skip  = (page - 1) * limit;
    const where: any = {};

    if (filters?.role)                   where.role     = filters.role;
    if (filters?.isActive !== undefined) where.isActive = filters.isActive;
    if (filters?.search) {
      where.OR = [
        { name:  { contains: filters.search, mode: 'insensitive' } },
        { email: { contains: filters.search, mode: 'insensitive' } },
        { phone: { contains: filters.search, mode: 'insensitive' } },
      ];
    }

    const users = await this.prisma.user.findMany({
      where,
      select: {
        id:        true,
        name:      true,
        email:     true,
        role:      true,
        phone:     true,
        address:   true,
        isActive:  true,
        balance:   true,
        createdAt: true,
        parentId:  true,
        parent: { select: { id: true, name: true, email: true, role: true } },
      },
      skip,
      take:    limit,
      orderBy: { createdAt: 'desc' },
    });

    const total = await this.prisma.user.count({ where });

    const usersWithCounts = await Promise.all(
      users.map(async (user) => {
        const [ownedSubscribersCount, childrenCount] = await Promise.all([
          this.prisma.subscriber.count({ where: { userId: user.id } }),
          this.prisma.user.count({ where: { parentId: user.id } }),
        ]);
        return {
          ...user,
          _count: { ownedSubscribers: ownedSubscribersCount, children: childrenCount },
        };
      }),
    );

    return {
      data: usersWithCounts,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    };
  }

  async findByRole(role: string) {
    return this.prisma.user.findMany({
      where:   { role: role as any, isActive: true },
      select:  { id: true, name: true, email: true, role: true, phone: true, balance: true },
      orderBy: { name: 'asc' },
    });
  }

  async findByParent(parentId: number) {
    const users = await this.prisma.user.findMany({
      where:  { parentId, isActive: true },
      select: { id: true, name: true, email: true, role: true, phone: true, balance: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });

    return Promise.all(
      users.map(async (user) => {
        const [ownedSubscribersCount, childrenCount] = await Promise.all([
          this.prisma.subscriber.count({ where: { userId: user.id } }),
          this.prisma.user.count({ where: { parentId: user.id } }),
        ]);
        return { ...user, _count: { ownedSubscribers: ownedSubscribersCount, children: childrenCount } };
      }),
    );
  }

  async getUserHierarchy(userId: number) {
    const user = await this.findOne(userId);

    const getChildren = async (id: number): Promise<any[]> => {
      const children = await this.prisma.user.findMany({
        where:  { parentId: id, isActive: true },
        select: { id: true, name: true, email: true, role: true, phone: true, balance: true, createdAt: true },
      });

      for (const child of children) {
        const subscribersCount = await this.prisma.subscriber.count({ where: { userId: child.id } });
        (child as any).children  = await getChildren(child.id);
        (child as any)._count    = { ownedSubscribers: subscribersCount };
      }
      return children;
    };

    return { ...user, children: await getChildren(userId) };
  }

  async findOne(id: number) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id:        true,
        name:      true,
        email:     true,
        role:      true,
        phone:     true,
        address:   true,
        isActive:  true,
        balance:   true,
        parentId:  true,
        createdAt: true,
        updatedAt: true,
        parent: { select: { id: true, name: true, email: true, role: true } },
      },
    });

    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    const [
      ownedSubscribersCount,
      childrenCount,
      paymentsCount,
      ticketsCount,
      recentSubscribers,
      recentPayments,
      recentTickets,
    ] = await Promise.all([
      this.prisma.subscriber.count({ where: { userId: id } }),
      this.prisma.user.count({ where: { parentId: id } }),
      this.prisma.payment.count({ where: { receivedBy: id } }),
      this.prisma.ticket.count({ where: { assignedTo: id } }),
      this.prisma.subscriber.findMany({
        where:   { userId: id },
        take:    10,
        orderBy: { createdAt: 'desc' },
        select:  {
          id: true, fullName: true, phone: true, status: true,
          package: { select: { name: true, price: true } },
        },
      }),
      this.prisma.payment.findMany({
        where:   { receivedBy: id },
        take:    10,
        orderBy: { createdAt: 'desc' },
        select:  {
          id: true, amount: true, method: true, paymentDate: true,
          invoice: { select: { invoiceNo: true } },
        },
      }),
      this.prisma.ticket.findMany({
        where:   { assignedTo: id },
        take:    10,
        orderBy: { createdAt: 'desc' },
        select:  { id: true, ticketNo: true, subject: true, status: true, priority: true, createdAt: true },
      }),
    ]);

    const children = await this.prisma.user.findMany({
      where:  { parentId: id },
      select: { id: true, name: true, email: true, role: true, isActive: true, balance: true },
    });

    const childrenWithCounts = await Promise.all(
      children.map(async (child) => {
        const subscribersCount = await this.prisma.subscriber.count({ where: { userId: child.id } });
        return { ...child, _count: { ownedSubscribers: subscribersCount } };
      }),
    );

    return {
      ...user,
      children:         childrenWithCounts,
      subscribers:      recentSubscribers,
      payments:         recentPayments,
      assignedTickets:  recentTickets,
      _count: {
        ownedSubscribers: ownedSubscribersCount,
        children:         childrenCount,
        payments:         paymentsCount,
        assignedTickets:  ticketsCount,
      },
    };
  }

  async getStats() {
    const [
      total, activeUsers, inactiveUsers,
      superAdmins, admins, sales, resellers, subResellers, retailers,
      totalBalance,
    ] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.user.count({ where: { isActive: true } }),
      this.prisma.user.count({ where: { isActive: false } }),
      this.prisma.user.count({ where: { role: 'SUPER_ADMIN' } }),
      this.prisma.user.count({ where: { role: 'ADMIN' } }),
      this.prisma.user.count({ where: { role: 'SALES' } }),
      this.prisma.user.count({ where: { role: 'RESELLER' } }),
      this.prisma.user.count({ where: { role: 'SUB_RESELLER' } }),
      this.prisma.user.count({ where: { role: 'RETAILER' } }),
      this.prisma.user.aggregate({
        _sum:  { balance: true },
        where: { role: { in: ['RESELLER', 'SUB_RESELLER', 'RETAILER'] as any } },
      }),
    ]);

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentUsers = await this.prisma.user.count({ where: { createdAt: { gte: thirtyDaysAgo } } });

    const usersWithSubscribersResult: any = await this.prisma.$queryRaw`
      SELECT COUNT(DISTINCT "userId") as count
      FROM "Subscriber"
      WHERE "userId" IS NOT NULL
    `;
    const usersWithSubscribers = Number(usersWithSubscribersResult[0]?.count || 0);

    return {
      total,
      activeUsers,
      inactiveUsers,
      recentUsers,
      superAdmins,
      admins,
      sales,
      resellers,
      subResellers,
      retailers,
      totalBalance: totalBalance._sum.balance ?? 0,
      usersWithSubscribers,
      byRole: [
        { role: 'SUPER_ADMIN',  count: superAdmins  },
        { role: 'ADMIN',        count: admins        },
        { role: 'SALES',        count: sales         },
        { role: 'RESELLER',     count: resellers     },
        { role: 'SUB_RESELLER', count: subResellers  },
        { role: 'RETAILER',     count: retailers     },
      ],
    };
  }

  async create(data: {
    name:       string;
    email:      string;
    password:   string;
    role:       string;
    phone?:     string;
    address?:   string;
    parentId?:  number;
    balance?:   number;
  }) {
    const existing = await this.prisma.user.findUnique({ where: { email: data.email } });
    if (existing) throw new ConflictException(`User with email ${data.email} already exists`);

    if (data.parentId) {
      const parent = await this.prisma.user.findUnique({ where: { id: data.parentId } });
      if (!parent) throw new NotFoundException(`Parent user with ID ${data.parentId} not found`);

      const validParentRoles: Record<string, string[]> = {
        RESELLER:    ['SUB_RESELLER', 'RETAILER'],
        SUB_RESELLER: ['RETAILER'],
        ADMIN:       ['RESELLER', 'SUB_RESELLER', 'RETAILER', 'SALES'],
        SUPER_ADMIN: ['ADMIN', 'RESELLER', 'SUB_RESELLER', 'RETAILER', 'SALES'],
      };

      const allowed = validParentRoles[parent.role];
      if (allowed && !allowed.includes(data.role)) {
        throw new BadRequestException(
          `A ${parent.role} cannot create a ${data.role} user. Allowed: ${allowed.join(', ')}`,
        );
      }
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);

    return this.prisma.user.create({
      data: {
        name:      data.name,
        email:     data.email,
        password:  hashedPassword,
        role:      data.role as any,
        phone:     data.phone,
        address:   data.address,
        parentId:  data.parentId,
        balance:   data.balance || 0,
      },
      select: {
        id: true, name: true, email: true, role: true,
        phone: true, address: true, isActive: true, balance: true,
        parentId: true, createdAt: true,
      },
    });
  }

  async update(
    id:   number,
    data: {
      name?:      string;
      email?:     string;
      password?:  string;
      role?:      string;
      phone?:     string;
      address?:   string;
      parentId?:  number;
      isActive?:  boolean;
    },
  ) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    if (data.email && data.email !== user.email) {
      const existing = await this.prisma.user.findUnique({ where: { email: data.email } });
      if (existing) throw new ConflictException(`User with email ${data.email} already exists`);
    }

    if (data.parentId !== undefined) {
      if (data.parentId === id) throw new BadRequestException('User cannot be their own parent');

      if (data.parentId) {
        const parent = await this.prisma.user.findUnique({ where: { id: data.parentId } });
        if (!parent) throw new NotFoundException(`Parent user with ID ${data.parentId} not found`);

        let currentParentId = parent.parentId;
        while (currentParentId) {
          if (currentParentId === id) throw new BadRequestException('Circular hierarchy detected');
          const currentParent = await this.prisma.user.findUnique({ where: { id: currentParentId } });
          currentParentId = currentParent?.parentId ?? null;
        }
      }
    }

    const updateData: any = { ...data };
    if (data.password) {
      updateData.password = await bcrypt.hash(data.password, 10);
    } else {
      delete updateData.password;
    }

    return this.prisma.user.update({
      where: { id },
      data:  updateData,
      select: {
        id: true, name: true, email: true, role: true,
        phone: true, address: true, isActive: true, balance: true,
        parentId: true, updatedAt: true,
      },
    });
  }

  async delete(id: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    const subscribersCount = await this.prisma.subscriber.count({ where: { userId: id } });
    if (subscribersCount > 0) {
      throw new BadRequestException(
        `Cannot delete user with ${subscribersCount} subscribers. Reassign or delete subscribers first.`,
      );
    }

    const childrenCount = await this.prisma.user.count({ where: { parentId: id } });
    if (childrenCount > 0) {
      throw new BadRequestException(
        `Cannot delete user with ${childrenCount} child users. Reassign or delete children first.`,
      );
    }

    return this.prisma.user.delete({ where: { id } });
  }

  async softDelete(id: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);
    return this.prisma.user.update({ where: { id }, data: { isActive: false } });
  }

  async restore(id: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);
    return this.prisma.user.update({ where: { id }, data: { isActive: true } });
  }

  async toggleStatus(id: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);
    return this.prisma.user.update({
      where: { id },
      data:  { isActive: !user.isActive },
      select: { id: true, name: true, isActive: true },
    });
  }

  async changeRole(id: number, role: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    const validRoles = ['SUPER_ADMIN', 'ADMIN', 'SALES', 'RESELLER', 'SUB_RESELLER', 'RETAILER'];
    if (!validRoles.includes(role)) {
      throw new BadRequestException(`Invalid role. Must be one of: ${validRoles.join(', ')}`);
    }

    return this.prisma.user.update({
      where: { id },
      data:  { role: role as any },
      select: { id: true, name: true, email: true, role: true },
    });
  }

  async addBalance(id: number, amount: number) {
    if (amount <= 0) throw new BadRequestException('Amount must be greater than 0');

    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    const allowedRoles = ['RESELLER', 'SUB_RESELLER', 'RETAILER'];
    if (!allowedRoles.includes(user.role)) {
      throw new ForbiddenException(`Balance can only be added to ${allowedRoles.join(', ')} roles`);
    }

    return this.prisma.user.update({
      where: { id },
      data:  { balance: { increment: amount } },
      select: { id: true, name: true, role: true, balance: true },
    });
  }

  async deductBalance(id: number, amount: number) {
    if (amount <= 0) throw new BadRequestException('Amount must be greater than 0');

    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    if (user.balance < amount) {
      throw new BadRequestException(`Insufficient balance. Current balance: ${user.balance}`);
    }

    return this.prisma.user.update({
      where: { id },
      data:  { balance: { decrement: amount } },
      select: { id: true, name: true, role: true, balance: true },
    });
  }

  async getBalance(id: number) {
    const user = await this.prisma.user.findUnique({
      where:  { id },
      select: { id: true, name: true, role: true, balance: true },
    });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);
    return user;
  }

  async getUserDashboardSummary(id: number) {
    const user = await this.findOne(id);

    const [totalSubscribers, activeSubscribers, totalRevenue, pendingTickets] = await Promise.all([
      this.prisma.subscriber.count({ where: { userId: id } }),
      this.prisma.subscriber.count({ where: { userId: id, status: 'ACTIVE' } }),
      this.prisma.payment.aggregate({ _sum: { amount: true }, where: { receivedBy: id } }),
      this.prisma.ticket.count({ where: { assignedTo: id, status: { not: 'CLOSED' } } }),
    ]);

    return {
      user: { id: user.id, name: user.name, role: user.role, balance: user.balance },
      stats: {
        totalSubscribers,
        activeSubscribers,
        totalRevenue: totalRevenue._sum.amount ?? 0,
        pendingTickets,
      },
    };
  }
}
