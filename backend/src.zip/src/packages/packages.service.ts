import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PackagesService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.package.findMany({
      orderBy: { price: 'asc' },
    });
  }

  async findOne(id: number) {
    const pkg = await this.prisma.package.findUnique({
      where: { id },
      include: {
        _count: { select: { subscribers: true } },
      },
    });
    
    if (!pkg) {
      throw new NotFoundException('Package not found');
    }
    return pkg;
  }

  async getStats() {
    const total = await this.prisma.package.count();
    const active = await this.prisma.package.count({ where: { isActive: true } });
    const inactive = await this.prisma.package.count({ where: { isActive: false } });
    
    const totalSubscribers = await this.prisma.subscriber.count({
      where: { packageId: { not: null } },
    });
    
    return { total, active, inactive, totalSubscribers };
  }

  async create(data: any) {
    return this.prisma.package.create({
      data: {
        name: data.name,
        speed: data.speed,
        price: parseFloat(data.price),
        description: data.description,
        serviceType: data.serviceType || 'RESIDENTIAL',
        quota: data.quota,
        fup: data.fup,
        ipPool: data.ipPool,
        tax: parseFloat(data.tax) || 0,
        durationType: data.durationType || 'MONTHLY',
        autoRenew: data.autoRenew === 'true' || data.autoRenew === true,
        setupFee: parseFloat(data.setupFee) || 0,
        contractTerm: data.contractTerm ? parseInt(data.contractTerm) : null,
        lateFee: parseFloat(data.lateFee) || 0,
        isActive: data.isActive !== undefined ? data.isActive : true,
      },
    });
  }

  async update(id: number, data: any) {
    const existing = await this.prisma.package.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException('Package not found');
    }
    
    return this.prisma.package.update({
      where: { id },
      data: {
        name: data.name,
        speed: data.speed,
        price: parseFloat(data.price),
        description: data.description,
        serviceType: data.serviceType,
        quota: data.quota,
        fup: data.fup,
        ipPool: data.ipPool,
        tax: parseFloat(data.tax) || 0,
        durationType: data.durationType,
        autoRenew: data.autoRenew === 'true' || data.autoRenew === true,
        setupFee: parseFloat(data.setupFee) || 0,
        contractTerm: data.contractTerm ? parseInt(data.contractTerm) : null,
        lateFee: parseFloat(data.lateFee) || 0,
        isActive: data.isActive,
      },
    });
  }

  async remove(id: number) {
    const existing = await this.prisma.package.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException('Package not found');
    }
    
    return this.prisma.package.delete({ where: { id } });
  }

  async toggleStatus(id: number) {
    const pkg = await this.prisma.package.findUnique({ where: { id } });
    if (!pkg) {
      throw new NotFoundException('Package not found');
    }
    
    return this.prisma.package.update({
      where: { id },
      data: { isActive: !pkg.isActive },
    });
  }
}