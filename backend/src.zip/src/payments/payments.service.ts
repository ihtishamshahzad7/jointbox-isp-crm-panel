import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PaymentsService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.payment.findMany({
      include: {
        invoice: true,
        subscriber: true,
        receivedByUser: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    return this.prisma.payment.findUnique({
      where: { id },
      include: {
        invoice: true,
        subscriber: true,
        receivedByUser: true,
      },
    });
  }

  async findBySubscriber(subscriberId: number) {
    return this.prisma.payment.findMany({
      where: { subscriberId },
      include: {
        invoice: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getStats() {
    const total = await this.prisma.payment.count();
    const totalAmount = await this.prisma.payment.aggregate({
      _sum: { amount: true },
    });
    const byMethod = await this.prisma.payment.groupBy({
      by: ['method'],
      _sum: { amount: true },
      _count: true,
    });
    
    return {
      total,
      totalAmount: totalAmount._sum.amount || 0,
      byMethod,
    };
  }

  async create(data: any) {
    const paymentNo = `PAY-${Date.now()}`;
    return this.prisma.payment.create({
      data: {
        paymentNo,
        invoiceId: data.invoiceId,
        subscriberId: data.subscriberId,
        amount: data.amount,
        method: data.method,
        referenceNo: data.referenceNo,
        notes: data.notes,
        receivedBy: data.receivedBy,
      },
      include: {
        invoice: true,
        subscriber: true,
      },
    });
  }
}