import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AreasService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.area.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        subscribers: true,
        _count: {
          select: {
            subscribers: true,
          },
        },
      },
    });
  }

  async findOne(id: number) {
    return this.prisma.area.findUnique({
      where: { id },
      include: {
        subscribers: true,
        _count: {
          select: {
            subscribers: true,
          },
        },
      },
    });
  }

  async create(data: {
    name: string;
    city?: string;
    description?: string;
  }) {
    return this.prisma.area.create({
      data,
    });
  }

  async update(id: number, data: any) {
    return this.prisma.area.update({
      where: { id },
      data,
    });
  }

  async remove(id: number) {
    return this.prisma.area.delete({
      where: { id },
    });
  }

  async toggleArea(id: number) {
    const area = await this.prisma.area.findUnique({
      where: { id },
    });

    if (!area) {
      throw new Error('Area not found ❌');
    }

    return this.prisma.area.update({
      where: { id },
      data: {
        isActive: !area.isActive,
      },
    });
  }

  async getStats() {
    const total = await this.prisma.area.count();

    // ⚠️ SAFE FIX: only use isActive if it exists in schema
    const active = await this.prisma.area.count({
      where: { isActive: true },
    });

    const inactive = await this.prisma.area.count({
      where: { isActive: false },
    });

    return { total, active, inactive };
  }
}