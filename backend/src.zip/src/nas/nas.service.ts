import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NasType } from '@prisma/client';

@Injectable()
export class NasService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.nas.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { subscribers: true } },
      },
    });
  }

  async findOne(id: number) {
    return this.prisma.nas.findUnique({
      where: { id: id },
      include: {
        subscribers: true,
        _count: { select: { subscribers: true } },
      },
    });
  }

  async create(data: {
    nasIp: string;
    nasName: string;
    radiusSecret: string;
    incomingPort?: number;
    apiPort?: number;
    apiUsername?: string;
    apiPassword?: string;
    nasType?: string;
    isActive?: boolean;
    description?: string;
  }) {
    // Convert string to NasType enum
    let nasTypeEnum: NasType = NasType.MIKROTIK;
    if (data.nasType === 'CISCO') nasTypeEnum = NasType.CISCO;
    if (data.nasType === 'HUAWEI') nasTypeEnum = NasType.HUAWEI;
    if (data.nasType === 'OTHER') nasTypeEnum = NasType.OTHER;

    return this.prisma.nas.create({
      data: {
        nasIp: data.nasIp,
        nasName: data.nasName,
        radiusSecret: data.radiusSecret,
        incomingPort: data.incomingPort || 3799,
        apiPort: data.apiPort || 8728,
        apiUsername: data.apiUsername,
        apiPassword: data.apiPassword,
        nasType: nasTypeEnum,
        isActive: data.isActive !== undefined ? data.isActive : true,
        description: data.description,
      },
    });
  }

  async update(id: number, data: any) {
    // If nasType is being updated, convert it to enum
    if (data.nasType) {
      let nasTypeEnum: NasType = NasType.MIKROTIK;
      if (data.nasType === 'CISCO') nasTypeEnum = NasType.CISCO;
      if (data.nasType === 'HUAWEI') nasTypeEnum = NasType.HUAWEI;
      if (data.nasType === 'OTHER') nasTypeEnum = NasType.OTHER;
      data.nasType = nasTypeEnum;
    }
    
    return this.prisma.nas.update({
      where: { id: id },
      data: data,
    });
  }

  async remove(id: number) {
    return this.prisma.nas.delete({
      where: { id: id },
    });
  }

  async toggleStatus(id: number) {
    const nas = await this.prisma.nas.findUnique({ where: { id: id } });
    if (!nas) {
      throw new Error('NAS not found');
    }
    return this.prisma.nas.update({
      where: { id: id },
      data: { isActive: !nas.isActive },
    });
  }

  async getStats() {
    const total = await this.prisma.nas.count();
    const active = await this.prisma.nas.count({ where: { isActive: true } });
    const inactive = await this.prisma.nas.count({ where: { isActive: false } });
    return { total, active, inactive };
  }
}