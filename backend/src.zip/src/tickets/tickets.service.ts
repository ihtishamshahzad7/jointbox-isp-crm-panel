import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TicketsService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.ticket.findMany({
      include: {
        subscriber: { select: { id: true, fullName: true, phone: true } },
        assignedUser: { select: { id: true, name: true } },
        // messages removed for now (schema mismatch safe mode)
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    return this.prisma.ticket.findUnique({
      where: { id },
      include: {
        subscriber: true,
        assignedUser: true,
        // messages removed for now
      },
    });
  }

  async findBySubscriber(subscriberId: number) {
    return this.prisma.ticket.findMany({
      where: { subscriberId },
      orderBy: { createdAt: 'desc' },
      include: {
        // messages removed for now
      },
    });
  }

  async getStats() {
    const total = await this.prisma.ticket.count();
    const open = await this.prisma.ticket.count({ where: { status: 'OPEN' } });
    const inProgress = await this.prisma.ticket.count({ where: { status: 'IN_PROGRESS' } });
    const resolved = await this.prisma.ticket.count({ where: { status: 'RESOLVED' } });
    const closed = await this.prisma.ticket.count({ where: { status: 'CLOSED' } });

    const byCategory = await this.prisma.ticket.groupBy({
      by: ['category'],
      _count: {
        _all: true,
      },
    });

    return { total, open, inProgress, resolved, closed, byCategory };
  }

  async generateTicketNo() {
    const count = await this.prisma.ticket.count();
    return `TKT-${new Date().getFullYear()}-${String(count + 1).padStart(5, '0')}`;
  }

  async create(data: any) {
    const ticketNo = await this.generateTicketNo();

    return this.prisma.ticket.create({
      data: {
        ticketNo,
        subscriberId: Number(data.subscriberId),
        category: data.category,
        priority: data.priority || 'MEDIUM',
        subject: data.subject,
        description: data.description,
        assignedTo: data.assignedTo ? Number(data.assignedTo) : null,
        status: 'OPEN',
      },
      include: {
        subscriber: true,
      },
    });
  }

  async update(id: number, data: any) {
    return this.prisma.ticket.update({
      where: { id },
      data: {
        category: data.category,
        priority: data.priority,
        status: data.status,
        assignedTo: data.assignedTo ? Number(data.assignedTo) : null,
        resolution: data.resolution,
        resolvedAt:
          data.status === 'RESOLVED' ? new Date() : undefined,
      },
    });
  }

  async addMessage(ticketId: number, data: any) {
    return this.prisma.ticketMessage.create({
      data: {
        ticketId: Number(ticketId),
        message: data.message,
        attachmentUrl: data.attachmentUrl,
        sentBy: Number(data.sentBy),
        sentByType: data.sentByType || 'STAFF',
      },
    });
  }

  async delete(id: number) {
    return this.prisma.ticket.delete({ where: { id } });
  }
}